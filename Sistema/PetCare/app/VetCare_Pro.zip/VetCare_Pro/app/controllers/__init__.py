"""
VetCare Pro - Controladores (Blueprints)
"""
# Este archivo está vacío intencionalmente
# Los blueprints se importan directamente desde cada módulo
